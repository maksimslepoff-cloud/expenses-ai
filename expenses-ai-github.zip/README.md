# Мои расходы + ИИ

## Файлы
- `expenses_ai.html` — приложение
- `server.mjs` — сервер и API ИИ
- `package.json` — зависимости
- `.env.example` — пример переменных
- `README.md` — инструкция

## Render
Build Command: `npm install`
Start Command: `npm start`

В Environment Variables добавьте:
`OPENAI_API_KEY` = ваш API-ключ

API-ключ не добавляйте в HTML и не загружайте настоящий `.env` в GitHub.
