import "dotenv/config";
import express from "express";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = Number(process.env.PORT || 3000);
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(express.json({ limit: "100kb" }));
app.use(express.static(__dirname));

app.post("/api/analyze", async (req, res) => {
  try {
    const transactions = Array.isArray(req.body?.transactions) ? req.body.transactions : [];
    if (!transactions.length) return res.status(400).json({ error: "Нет операций для анализа." });

    const clean = transactions.slice(-500).map(x => ({
      type: x.type === "income" ? "income" : "expense",
      amount: Number(x.amount) || 0,
      category: String(x.category || "Другое").slice(0, 60),
      note: String(x.note || "").slice(0, 160),
      date: String(x.date || "").slice(0, 40)
    }));

    const prompt = `Проанализируй личные расходы пользователя по операциям ниже.
Не осуждай пользователя и не выдумывай данные. Используй только переданные операции.
Ответ на русском языке:
1. Главные наблюдения — 2-4 пункта.
2. Где можно сократить — 3-5 конкретных идей с суммами или долями, если их можно посчитать.
3. План экономии — 3 действия на ближайшие 30 дней.
4. Потенциальная экономия — осторожный диапазон в рублях только при наличии оснований.
Если данных мало, прямо скажи об этом.
Операции:
${JSON.stringify(clean)}`;

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
      input: prompt
    });

    res.json({ analysis: response.output_text || "Не удалось получить анализ." });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Ошибка ИИ-сервера. Проверьте OPENAI_API_KEY и модель." });
  }
});

app.listen(port, () => console.log(`Server running on port ${port}`));
